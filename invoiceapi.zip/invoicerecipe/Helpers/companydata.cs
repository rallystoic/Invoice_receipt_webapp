using System;
namespace invoicerecipe.Helpers  {
	public class CompanyData {
		public string companyname {get;set;}
		public string address  {get;set;}
		public string district {get;set;}
		public string province {get;set;}
		public string phone  {get;set;}
		public string postal_code   {get;set;}
	}

}


