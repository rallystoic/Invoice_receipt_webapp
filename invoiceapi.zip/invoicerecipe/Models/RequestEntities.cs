using System.Collections.Generic;
using System;

namespace invoicerecipe.Models
{
	// customer payload
	public class customerpayload {
 		public string first_name {get;set;}
 		public string last_name {get;set;}
 		public string phone {get;set;}
 		public string address {get;set;}
 		public string district {get;set;}
 		public string province {get;set;}
 		public string postal_code {get;set;}
 		public string companyname {get;set;}
	}
	// creating an invoicce
	// order -> items -> invoice
	public class invoicepayload {
		public invoicepayload(){
		this.items = new List<item>();	
		}
		public int customerid {get;set;}
		public List<item> items {get;set;}
	}
	public class itemlist {
	public string description {get;set;}
	public string quantity {get;set;}
	public string price {get;set;}
	}
	// second option use IList
	public class invoicepayloadgg {
	 	public invoicepayloadgg(){
	 	itemlists = new List<itemlist>();
	 	}
	public int customerid {get;set;}	
	public List<itemlist> itemlists {get;set;}
	}
	// 3rd option use array
	public class invoicepayloadarr {
	public int customerid {get;set;}	
	public itemlist[] itemlists {get;set;}
	}

	public class userrequest
	{
		public string username {get;set;}
		public string password {get;set;}
	}



	
}

