using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
namespace invoicerecipe.Models
{
	public class InvoiceContext : DbContext
	{
		public InvoiceContext(DbContextOptions<InvoiceContext> options)
			: base(options)
		{
		}

		public DbSet<order> order {get;set;}
		public DbSet<item> item {get;set;}
		public DbSet<invoice> invoice {get;set;}
		public DbSet<customer> customer {get;set;}
		public DbSet<user> user {get;set;}
		public DbSet<admin> admin {get;set;}

	}
	
}
