using System.Collections.Generic;
using System;

namespace invoicerecipe.Models
{
	public class admin{
		public int adminid {get;set;}
		public string username {get;set;}
		public string usersalt {get;set;}
		public string userhashed {get;set;}
		public string rolename {get;set;}
	}
	public class user 
	{
		public int  userid {get;set;}
		public string username {get;set;}
		public string usersalt {get;set;}
		public string userhashed {get;set;}
		public string rolename {get;set;}
		public int  customerid {get;set;}
		public customer customer {get;set;}
	}
 	public class customer
 	{
 		public int customerid {get;set;}
 		public string first_name {get;set;}
 		public string last_name {get;set;}
 		public string phone {get;set;}
 		public string address {get;set;}
 		public string district {get;set;}
 		public string province {get;set;}
 		public string postal_code {get;set;}
 		public string companyname {get;set;}
 		// reference to order table
 		public ICollection<order> order {get;set;}
 		public ICollection<user> user {get;set;}
 	}
    public class order
    {
	    public int orderid {get;set;}
	    public int customerid {get;set;}
	    public customer customer {get;set;}

	    public ICollection<item> item {get;set;}
	    public ICollection<invoice> invoice {get;set;}
    }
    public class item
    {
	    public int itemid {get;set;}
	    public string description {get;set;}
	    public int quantity {get;set;}
	    public decimal price {get;set;}

	    public int orderid {get;set;}
	    public order order {get;set;}
    }
    public class invoice 
    {
	    public int invoiceid {get;set;}
	    public int orderid {get;set;}
	    public order order {get;set;}
	    public decimal amount {get;set;}
	    public DateTime date {get;set;}
    }
   
}
