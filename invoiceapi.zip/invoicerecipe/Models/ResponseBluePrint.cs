using System.Collections.Generic;
using System;
namespace invoicerecipe.Models
{

	public class IssucceedInfomation{
		public bool issucceed {get;set;}
		public string detail {get;set;}
	}


	public class Invoicedetail {
		public Invoicedetail(){
		this.rsitems = new List<rsitem>();
		}
	public string invoiceid {get;set;}
	public string  date {get;set;}
	//company name section
	public string c_companyname {get;set;}
 	public string c_address {get;set;}
 	public string c_district {get;set;}
 	public string c_province {get;set;}
 	public string c_postal_code {get;set;}
	//company name section
	
	// bill to section
	public string fullname {get;set;}
 	public string phone {get;set;}
 	public string address {get;set;}
 	public string district {get;set;}
 	public string province {get;set;}
 	public string postal_code {get;set;}
 	public string companyname {get;set;}
	// bill section
	
	// item section
	public IList<rsitem> rsitems {get;set;}
	// End item section
	public string total {get;set;}
	}

	// response of itemslist
	//  ->will be use inside invoice detail
    public class rsitem
    {
	    public string description {get;set;}
	    public string quantity {get;set;}
	    public string price {get;set;}
    }
    // response object for customer 
    //  -> customerID firstname lastname
    //  this entitiy will be use for creating an invoice
    public class rscustomer
    {
	    public int customerid {get;set;}
	    public string fullname {get;set;}
	    public string phonenumber {get;set;}
    }
	// return an array of invoicelist
    public class invoices {
	   public string id {get;set;}
	   public string invoiceid {get;set;}
	   public string amount {get;set;}
	   public string date {get;set;}
    }
    public class Total {
	    public int total {get;set;}
    }

}

