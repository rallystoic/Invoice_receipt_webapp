using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

//
using invoicerecipe.Models;
// ../Models/entities.cs
// ../Models/RequestEntities.cs
using Microsoft.EntityFrameworkCore;

using Microsoft.AspNetCore.Authorization;

namespace invoicerecipe.Controllers
{
    [Authorize (Policy = "Require_admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class itemsController : ControllerBase
    {
	    private readonly InvoiceContext _Context;
	    public itemsController(InvoiceContext Context){
		    _Context = Context;
	    }
	   // add a collection of item or one
	    [HttpPost]
	    public IActionResult additems(invoicepayloadgg invopayload){
		    IssucceedInfomation issucceedinfomation = new IssucceedInfomation();
 		    // check itemlegth
			decimal Nprice;
		    // Console.WriteLine("length of itemlists : " + invopayload.itemlists.Count);
 		    if(invopayload.itemlists.Count  == 0){
 		issucceedinfomation.issucceed = false;	
 		issucceedinfomation.detail = "empty array";
 		return Ok(issucceedinfomation);
 		    }
		    decimal total = 0.00M;
		    order Neworder = new order(){
		  customerid = invopayload.customerid
		    };
		    _Context.order.Add(Neworder);
		    _Context.SaveChanges();
		    // add an array of items into Ilist<items> and saverange into db
		    IList<item> items = new List<item>();
		    foreach (var entry in invopayload.itemlists)
		    { 
			    if (string.IsNullOrEmpty(entry.description))
			    {
				    break;
			    }
			    Nprice = decimal.Parse(entry.price);
			    if(string.IsNullOrEmpty(entry.description) && string.IsNullOrEmpty(entry.price)){ break;}
			    item Newitem = new item(){
				description = entry.description,
				 //price = entry.price,
				 price = Nprice,
		     		//quantity = entry.quantity,
				quantity = int.Parse(entry.quantity),
				orderid = Neworder.orderid
			    };
			    //total += entry.price;
			    total += Nprice;
			    items.Add(Newitem);
		    }
		   _Context.item.AddRange(items); 
		   _Context.SaveChanges();
			   // Console.WriteLine( "object length added to database : "+ items.Count);
		   // create an invoice
		   invoice Newinvoice = new invoice(){
			   orderid = Neworder.orderid,
				  amount = total,
				  date = DateTime.UtcNow
		   };
		   _Context.invoice.Add(Newinvoice);
		   var result = _Context.SaveChanges();
		   issucceedinfomation.issucceed = true;
		   issucceedinfomation.detail = Newinvoice.invoiceid.ToString();
		    return Ok(issucceedinfomation);
	    }


    }
}
