using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using invoicerecipe.Models;
using Microsoft.EntityFrameworkCore;

using Microsoft.AspNetCore.Authorization;
namespace invoicerecipe.Controllers
{
    [Authorize (Policy = "Require_admin")]
	[Route("api/[controller]")]
		[ApiController]
			public class customerController : ControllerBase
		{
			private readonly InvoiceContext _Context;
			public customerController(InvoiceContext Context){
				_Context = Context;
			}
			//find customer by username
			 [HttpGet("find/username/{id}")]
			public IActionResult getinfo(){
			return Ok();
			 }

			// find customer by telephone
			[HttpGet("find/{phonenumber}")]
				public IActionResult findcustomerbyphone(string phonenumber){
				 IEnumerable<customer> cvalue = _Context.customer.Where(x=> x.phone.Contains(phonenumber)).Take(5).ToList();
				 IList<rscustomer> rsc = new List<rscustomer>();
				 foreach (var entry in cvalue) 
				 {
					var inserted = new rscustomer(){
					customerid = entry.customerid,
						fullname = entry.first_name + " " + entry.last_name,
						phonenumber = entry.phone
					 };
					rsc.Add(inserted);
				 }
					return Ok(rsc);
				}
			// get user detail
			[HttpGet("detail/{id}")]
			public IActionResult findcustomerbyphone(int id){
			customer csvalue = _Context.customer.FirstOrDefault(x=> x.customerid == id);
			return Ok(csvalue);
			}

			// create a customer
			[HttpPost]
			public IActionResult CreateCustomer(customerpayload cpayload) 
			{
			
			IssucceedInfomation issucceedinfomation = new IssucceedInfomation();
			if (cpayload.address.Length < 5)
			{
				issucceedinfomation.issucceed = false;
				issucceedinfomation.detail = "กรอก ข้อมูลให้ครบด้วย";
				return Ok(issucceedinfomation);
			}
			customer newcustomer = new customer(){
			first_name = cpayload.first_name.Trim(),
			last_name = cpayload.first_name.Trim(),
			phone = cpayload.phone.Trim(),
			address = cpayload.address,
			district = cpayload.district,
			province = cpayload.province,
			postal_code = cpayload.postal_code,
			companyname = cpayload.companyname
					};
					_Context.customer.Add(newcustomer);
					_Context.SaveChanges();
					issucceedinfomation.issucceed = true;
					return Ok(issucceedinfomation);
				}
		}
}
