using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using invoicerecipe.Services;
using invoicerecipe.Models;

namespace invoicerecipe.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class loginController : ControllerBase
    {
	    private IAuthenticationService _authservice {get;}
	    private InvoiceContext _Context {get;}
	    public loginController(
			   IAuthenticationService authservice,
			   InvoiceContext Context

			    ){
		 _authservice = authservice;
		 _Context = Context;
	    }

	    [HttpPost]
	    public IActionResult authenticate([FromBody]userrequest rq){
		    IssucceedInfomation issucceedinfomation = new IssucceedInfomation();
		     var uservalue = _Context.admin.FirstOrDefault(x=> x.username == rq.username);
		     if(uservalue == null){
			issucceedinfomation.issucceed = false;
			issucceedinfomation.detail = "Username  not found";
			return Ok(issucceedinfomation);
		     }
		     var result = _authservice.verifyHashed(rq.password, uservalue.usersalt, uservalue.userhashed);
		     if(result == false){
			    issucceedinfomation.issucceed = false;
			    issucceedinfomation.detail = "password inncorect";
			    return Ok(issucceedinfomation);
		     }
		     issucceedinfomation.issucceed = true;
		     issucceedinfomation.detail = _authservice.generatetokenWithoutid(uservalue.username,uservalue.rolename);
		    return Ok(issucceedinfomation);
	    }

    }
}
