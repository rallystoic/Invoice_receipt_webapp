using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
// config
using Microsoft.Extensions.Configuration;
using invoicerecipe.Models;
using invoicerecipe.Helpers;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;

namespace invoicerecipe.Controllers
{

    [Authorize (Policy = "Require_admin")]
	[Route("api/[controller]")]
		[ApiController]
			public class invoiceController : ControllerBase
		{
			private readonly InvoiceContext _Context;
			private readonly CompanyData _cpn;
			public invoiceController(InvoiceContext Context,
				IConfiguration Config,
				CompanyData cpn
				){
				_Context = Context;
				_cpn = cpn;
			}
			[HttpGet("detail/{id}")]
			public ActionResult invoicedetail(int id) 
			{
			// select itemlist from item table
			invoice valueinvoice = _Context.invoice.FirstOrDefault(x => x.invoiceid == id);
			if(valueinvoice == null){
			return BadRequest();
			}
			Invoicedetail invoicedetail = new Invoicedetail();		
			var result = from inv in _Context.invoice
			join o in _Context.order on inv.orderid equals o.orderid
			//join cs in _Context.customer on o.customerid equals cs.customerid
			join it in _Context.item on  o.orderid equals it.orderid 
			where inv.invoiceid == id
			select new {
			it.description,it.quantity,it.price,
				};
			// select data from customer table
			var customerresult = from inv in _Context.invoice 
			join o in _Context.order on inv.orderid equals o.orderid
			join cs in _Context.customer on o.customerid equals cs.customerid
			where inv.invoiceid == id
			select new {
				cs.companyname,
				cs.first_name,
				cs.last_name,
				cs.address,
				cs.district,
				cs.province,
				cs.postal_code
			};
			// invoice ref section
			                string invoice = valueinvoice.invoiceid.ToString();
					char pad = '0';
					 string refpad = "#" + invoice.PadLeft(8,pad);
			invoicedetail.invoiceid = refpad;
			invoicedetail.date = valueinvoice.date.AddHours(7).ToString("dd/MM/yyyy");
			invoicedetail.total = valueinvoice.amount.ToString();
			// company section 
			invoicedetail.c_companyname = _cpn.companyname;
			invoicedetail.c_address = _cpn.address;
			invoicedetail.c_district = _cpn.district;
			invoicedetail.c_province = _cpn.province;
			invoicedetail.c_postal_code = _cpn.postal_code;
			// End of company section
			// Customer section
			foreach (var entry in customerresult )
			{
			invoicedetail.companyname =  entry.companyname;
			invoicedetail.fullname = entry.first_name + " " + entry.last_name;
			invoicedetail.address  = entry.address;
			invoicedetail.district =  entry.district;
			invoicedetail.province =  entry.province;
			invoicedetail.postal_code =  entry.postal_code;
			}
			// Customer section
			// dealing with invoice items
			foreach (var entry in result)
			{
			rsitem Neorsitem = new rsitem(){	
				description = entry.description,
				price = entry.price.ToString(),
				quantity = entry.quantity.ToString()
			};
			invoicedetail.rsitems.Add(Neorsitem);
			}
					return Ok(invoicedetail);
			} // end function


			// total invoice object

			[HttpGet("total")]
			public async Task <ActionResult<Total>> totalinvoices() 
			{
				var count = await _Context.invoice.CountAsync();	
				var t = new Total();
				t.total = count;
				return Ok(t);
			}

			// invoice list
			[HttpGet("page/{id}")]
				public IActionResult CollectionOfinvoice(int id) {
					int maxcon = 9;
					int page = maxcon * id;
					var invoicelist = _Context.invoice.OrderByDescending(x=> x.invoiceid).Skip(page).Take(maxcon).ToArray();
					var invoicearry = new invoices[invoicelist.Length];	

					try
					{
					for (int i = 0; i < invoicelist.Length; i++)
					{
					char pad = '0';
					 string refpad = "#" + invoicelist[i].invoiceid.ToString().PadLeft(8,pad);
						var Ninvoice = new invoices{
						id = invoicelist[i].invoiceid.ToString(),
						invoiceid = refpad,
						amount = invoicelist[i].amount.ToString(),
						date = invoicelist[i].date.ToString("dd/MM/yyyy")
						};
						invoicearry[i] = Ninvoice;
					}
					}
					catch (System.Exception ex)
					{
						return Ok(ex.Message);
					}
					return Ok(invoicearry);
	
				}
    }
}

