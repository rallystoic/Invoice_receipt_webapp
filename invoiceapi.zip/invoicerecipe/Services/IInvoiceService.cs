using System;
using System.Text;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.AspNetCore.Http;

namespace invoicerecipe.Services {
	public interface IInvoiceService {
	}
	public class InvoiceService : IInvoiceService{
	}

}
