using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

using invoicerecipe.Models;
using invoicerecipe.Helpers;
using invoicerecipe.Services;


// entityframework
using Microsoft.EntityFrameworkCore;


// authentication section
// Json web token authentication section
using System.Text;
//jwt
using Microsoft.IdentityModel.Tokens;
// Authentication JWT
using Microsoft.AspNetCore.Authentication.JwtBearer;
// Reverse proxy forward a request to the app ( nginx -> net core)
using Microsoft.AspNetCore.HttpOverrides;


namespace invoicerecipe
{
	public class Startup
	{
		public Startup(IConfiguration configuration)
		{
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{
			CompanyData  cpn = new CompanyData();
			Configuration.Bind("CompanyData", cpn); // <--this
			services.AddSingleton(cpn);
			// cors policy
			services.AddCors(options =>
					{
					options.AddPolicy("cors",
							builder =>
							{
							builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();
							}
							);
					}
					); // end here
            services.AddControllers();
	    services.AddDbContext<InvoiceContext>(options => 
			    options.UseNpgsql(Configuration.GetConnectionString("database")));
			// dependencies Injection
		services.AddTransient<IAuthenticationService, AuthenticationService>();
			// End dependencies Injection

	    // * Authentication and Authorization section
                        var SecretKey = Encoding.ASCII.GetBytes(Configuration.GetConnectionString("secret"));
                        //Authentication
                        services.AddAuthentication(auth => {
                                        // authentication to jwt
                                        auth.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                                        auth.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                                        })
                        .AddJwtBearer(token => {
                                        // for https
                                        token.RequireHttpsMetadata = false;
                                        token.SaveToken = true;
                                        token.TokenValidationParameters = new TokenValidationParameters {
                                        ValidateIssuerSigningKey = true,
                                        //Secretkey
                                        IssuerSigningKey = new SymmetricSecurityKey(SecretKey),
                                        ValidateIssuer = false,
                                        ValidateAudience = false,
                                        RequireExpirationTime = true
                                        };
                                        });
                        // Authorization
                        services.AddAuthorization(options => {
                                        options.AddPolicy("Require_admin",
                                                        policy => policy.RequireRole("administrator")
                                                        );
                                        });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
	    app.UseForwardedHeaders(new ForwardedHeadersOptions
			    {
			    ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
			    });

            app.UseRouting();
	    app.UseCors("cors");
	    app.UseAuthentication();
	    app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
