export const environment = {
production: true,
 API_URL : 'http://localhost:5002'
// API_URL : 'https://invoiceapi.rallydemo.site'
};
